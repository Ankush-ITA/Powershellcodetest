## ENHC0010036_Shared_Folder_Access_PowerShell
    ## Developer
    - Parth Gupta (parth.gupta@capgemini.com)

    ## Description
    - This bot will add or remove the user from the security group of the shared folder depending on the read/read-write permission.

    ## Pre-Requisite
    - PowerShell (Version: 5.1.19041.3570; Edition: Desktop)
    - If BOT will be run from the windows Schedule, then Service Account should be created with required permissions and password.
    - Service Account creation is Account Scope.


    ## High-Level Logic
    - This bot will add or remove the user from the security group of the shared folder depending on the read/read-write permission.

    ## MicroBOT
    - This bot will check if the shared folder exists at the given path.
    - This bot will check if the provided security group exits for the given shared folder.
    - This bot will add the user to the security group with read permission.
    - This bot will add the user to the security group with read-write permission.
    - This bot will provide log details of the masterbot and microbots.

    ## Routines
    - **Decrypt Credential File**: The script decrypts credential files for secure server access.
    - **License Validation**: Validates the license file to ensure authorized usage.
    - **Log and Error Handling**: Logs detailed information using MicroBOT and handles exceptions.

    ## config.json
    - All BoT related configuration to be updated here.
    - Like Security Group, Permission, Username, Remove the user (Y or N), Target Name, Email ID, SMTP Server Name, Server PORT Address, Inputfile Name, Outfile Name, Mail Subject etc..
    
    ## Input Parameters
    - Before execution, this bot also need input parameters configured in "ENHC0010036_Shared_Folder_Access_PowerShell\input" directory.
    - Like Server names and Shared path of the folder.

    ## Output
    - After execution, this bot also generates the log file "ENHC0010036_Shared_Folder_Access_PowerShell\log" directory.

    ## License
    - Ensure you have a valid license file in the specified directory to run the script.
    - If License Expired please reach out to CREATE Development PoD.
    
    ## Note
    - BoT executable should be copied to the jump server.
    - Check permissions to access Jump servers and perform patch compliance checks.
    - Update the config file and the input files before executing the Bot.

    ## Dependencies
    - Below files must be present in the respective directory
    - ENHC0010036_Shared_Folder_Access_PowerShell\conf\License\license.txt (can be obtained from CREATE program for validity according to Client agreement)
    - ENHC0010036_Shared_Folder_Access_PowerShell\conf\Creds\secretkey.txt
    - ENHC0010036_Shared_Folder_Access_PowerShell\conf\Creds\vectorkey.txt